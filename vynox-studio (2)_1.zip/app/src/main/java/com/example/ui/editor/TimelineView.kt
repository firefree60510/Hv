package com.example.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.TransitionType
import com.example.model.VideoClip
import com.example.model.VynoxProject
import com.example.ui.theme.TimelinePlayhead
import com.example.ui.theme.TimelineRulerBg
import com.example.ui.theme.TimelineTrackBg
import com.example.ui.theme.VynoxBorder
import com.example.ui.theme.VynoxElectricBlue
import com.example.ui.theme.VynoxPurple
import com.example.ui.theme.VynoxPurpleGlow
import com.example.ui.theme.VynoxTextMuted
import com.example.ui.theme.VynoxTextPrimary
import com.example.ui.theme.VynoxTextSecondary
import java.util.Locale

@Composable
fun TimelineView(
    project: VynoxProject,
    playheadMs: Long,
    selectedClipIndex: Int?,
    timelineZoom: Float,
    onSeek: (Long) -> Unit,
    onSelectClip: (Int) -> Unit,
    onTrimClip: (clipIndex: Int, newStartMs: Long, newEndMs: Long) -> Unit,
    onSplitClip: () -> Unit,
    onDuplicateClip: (Int) -> Unit,
    onDeleteClip: (Int) -> Unit,
    onZoomChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val totalDurationMs = project.totalDurationMs
    // Px per second based on zoom: 1s = 60dp * zoom
    val dpPerSecond = 60f * timelineZoom
    val totalTimelineWidthDp = ((totalDurationMs / 1000f) * dpPerSecond).coerceAtLeast(360f).dp

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF0F0E17))
            .border(1.dp, VynoxBorder)
    ) {
        // Timeline Action Toolbar (Split, Duplicate, Delete, Zoom)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF141320))
                .padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Clip Tools
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Split
                IconButton(
                    onClick = onSplitClip,
                    enabled = selectedClipIndex != null,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("timeline_split_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCut,
                        contentDescription = "Split clip",
                        tint = if (selectedClipIndex != null) VynoxElectricBlue else VynoxTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Duplicate
                IconButton(
                    onClick = { selectedClipIndex?.let { onDuplicateClip(it) } },
                    enabled = selectedClipIndex != null,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("timeline_duplicate_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Duplicate clip",
                        tint = if (selectedClipIndex != null) VynoxPurpleGlow else VynoxTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Delete
                IconButton(
                    onClick = { selectedClipIndex?.let { onDeleteClip(it) } },
                    enabled = selectedClipIndex != null && project.videoClips.size > 1,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("timeline_delete_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete clip",
                        tint = if (selectedClipIndex != null && project.videoClips.size > 1) Color(0xFFF43F5E) else VynoxTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Timeline Zoom Controls
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { onZoomChange((timelineZoom - 0.25f).coerceAtLeast(0.5f)) },
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ZoomOut,
                        contentDescription = "Zoom out",
                        tint = VynoxTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Text(
                    text = "${(timelineZoom * 100).toInt()}%",
                    color = VynoxTextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )

                IconButton(
                    onClick = { onZoomChange((timelineZoom + 0.25f).coerceAtMost(3.0f)) },
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ZoomIn,
                        contentDescription = "Zoom in",
                        tint = VynoxTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Horizontal Multi-Track Container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(175.dp)
                .horizontalScroll(scrollState)
        ) {
            Column(modifier = Modifier.width(totalTimelineWidthDp)) {
                // Track 0: Time Ruler
                TimeRuler(
                    totalDurationMs = totalDurationMs,
                    dpPerSecond = dpPerSecond,
                    onSeek = onSeek
                )

                // Track 1: Text Overlays Track
                TextTrack(
                    project = project,
                    dpPerSecond = dpPerSecond
                )

                Spacer(modifier = Modifier.height(2.dp))

                // Track 2: Main Video Track
                VideoTrack(
                    project = project,
                    selectedClipIndex = selectedClipIndex,
                    dpPerSecond = dpPerSecond,
                    onSelectClip = onSelectClip,
                    onTrimClip = onTrimClip
                )

                Spacer(modifier = Modifier.height(2.dp))

                // Track 3: Audio & Voice Track
                AudioTrack(
                    project = project,
                    dpPerSecond = dpPerSecond
                )
            }

            // Playhead indicator
            val playheadOffsetDp = ((playheadMs / 1000f) * dpPerSecond).dp
            PlayheadIndicator(
                offsetDp = playheadOffsetDp,
                modifier = Modifier
                    .fillMaxHeight()
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val deltaMs = ((dragAmount.x / dpPerSecond) * 1000f).toLong()
                            onSeek((playheadMs + deltaMs).coerceIn(0L, totalDurationMs))
                        }
                    }
            )
        }
    }
}

@Composable
private fun TimeRuler(
    totalDurationMs: Long,
    dpPerSecond: Float,
    onSeek: (Long) -> Unit
) {
    val totalSeconds = (totalDurationMs / 1000).toInt() + 1
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(22.dp)
            .background(TimelineRulerBg)
            .pointerInput(Unit) {
                detectDragGestures { change, _ ->
                    val clickedSec = change.position.x / dpPerSecond
                    onSeek((clickedSec * 1000).toLong().coerceIn(0L, totalDurationMs))
                }
            }
    ) {
        for (sec in 0..totalSeconds) {
            Box(
                modifier = Modifier
                    .width(dpPerSecond.dp)
                    .fillMaxHeight()
            ) {
                // Tick mark
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(8.dp)
                        .background(Color(0xFF4B4963))
                        .align(Alignment.BottomStart)
                )

                // Time label
                val min = sec / 60
                val s = sec % 60
                Text(
                    text = String.format(Locale.US, "%02d:%02d", min, s),
                    color = VynoxTextMuted,
                    fontSize = 9.sp,
                    modifier = Modifier
                        .padding(start = 2.dp, top = 2.dp)
                        .align(Alignment.TopStart)
                )
            }
        }
    }
}

@Composable
private fun TextTrack(
    project: VynoxProject,
    dpPerSecond: Float
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(24.dp)
            .background(TimelineTrackBg)
    ) {
        project.textOverlays.forEach { textOverlay ->
            val startDp = ((textOverlay.startTimelineMs / 1000f) * dpPerSecond).dp
            val widthDp = (((textOverlay.endTimelineMs - textOverlay.startTimelineMs) / 1000f) * dpPerSecond)
                .coerceAtLeast(30f).dp

            Box(
                modifier = Modifier
                    .offset(x = startDp)
                    .width(widthDp)
                    .fillMaxHeight()
                    .padding(vertical = 2.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF581C87).copy(alpha = 0.85f))
                    .border(1.dp, VynoxPurpleGlow, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.TextFields,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = textOverlay.text,
                        color = Color.White,
                        fontSize = 10.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun VideoTrack(
    project: VynoxProject,
    selectedClipIndex: Int?,
    dpPerSecond: Float,
    onSelectClip: (Int) -> Unit,
    onTrimClip: (clipIndex: Int, newStartMs: Long, newEndMs: Long) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .background(Color(0xFF13121C))
    ) {
        project.videoClips.forEachIndexed { index, clip ->
            val clipWidthDp = ((clip.durationMs / 1000f) * dpPerSecond).coerceAtLeast(40f).dp
            val isSelected = selectedClipIndex == index
            val transition = project.transitions.firstOrNull { it.clipIndex == index }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Clip Block
                Box(
                    modifier = Modifier
                        .width(clipWidthDp)
                        .fillMaxHeight()
                        .padding(vertical = 2.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF1E1D2D))
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) VynoxPurpleGlow else VynoxBorder,
                            shape = RoundedCornerShape(6.dp)
                        )
                        .clickable { onSelectClip(index) }
                        .testTag("timeline_clip_$index")
                ) {
                    // Thumbnail background strip
                    AsyncImage(
                        model = clip.uri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF282638))
                    )

                    // Dark overlay for legibility
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.45f))
                    )

                    // Clip Name & Duration
                    Column(
                        modifier = Modifier
                            .padding(6.dp)
                            .align(Alignment.TopStart)
                    ) {
                        Text(
                            text = clip.name,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        val durSec = clip.durationMs / 1000f
                        Text(
                            text = String.format(Locale.US, "%.1fs", durSec),
                            color = VynoxElectricBlue,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Trimming handles when selected
                    if (isSelected) {
                        // Left trim handle
                        Box(
                            modifier = Modifier
                                .width(12.dp)
                                .fillMaxHeight()
                                .background(VynoxElectricBlue, RoundedCornerShape(topStart = 6.dp, bottomStart = 6.dp))
                                .align(Alignment.CenterStart)
                                .pointerInput(Unit) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        val deltaMs = ((dragAmount.x / dpPerSecond) * 1000f).toLong()
                                        val newStart = (clip.trimStartMs + deltaMs).coerceAtLeast(0L)
                                        if (newStart < clip.trimEndMs - 200L) {
                                            onTrimClip(index, newStart, clip.trimEndMs)
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Box(modifier = Modifier.size(2.dp, 16.dp).background(Color.Black))
                        }

                        // Right trim handle
                        Box(
                            modifier = Modifier
                                .width(12.dp)
                                .fillMaxHeight()
                                .background(VynoxElectricBlue, RoundedCornerShape(topEnd = 6.dp, bottomEnd = 6.dp))
                                .align(Alignment.CenterEnd)
                                .pointerInput(Unit) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        val deltaMs = ((dragAmount.x / dpPerSecond) * 1000f).toLong()
                                        val newEnd = (clip.trimEndMs + deltaMs).coerceAtMost(clip.sourceDurationMs)
                                        if (newEnd > clip.trimStartMs + 200L) {
                                            onTrimClip(index, clip.trimStartMs, newEnd)
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Box(modifier = Modifier.size(2.dp, 16.dp).background(Color.Black))
                        }
                    }
                }

                // Transition diamond button between clips
                if (index < project.videoClips.lastIndex) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .background(
                                if (transition != null && transition.type != TransitionType.NONE)
                                    VynoxPurple
                                else Color(0xFF262436),
                                CircleShape
                            )
                            .border(1.dp, VynoxBorder, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (transition != null && transition.type != TransitionType.NONE) "⚡" else "+",
                            color = Color.White,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AudioTrack(
    project: VynoxProject,
    dpPerSecond: Float
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(26.dp)
            .background(TimelineTrackBg)
    ) {
        project.audioClips.forEach { audioClip ->
            val startDp = ((audioClip.startTimelineMs / 1000f) * dpPerSecond).dp
            val widthDp = ((audioClip.durationMs / 1000f) * dpPerSecond).coerceAtLeast(30f).dp

            Box(
                modifier = Modifier
                    .offset(x = startDp)
                    .width(widthDp)
                    .fillMaxHeight()
                    .padding(vertical = 2.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        if (audioClip.isVoiceOver) Color(0xFF0F766E).copy(alpha = 0.9f)
                        else Color(0xFF0369A1).copy(alpha = 0.9f)
                    )
                    .border(1.dp, Color(0xFF38BDF8), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (audioClip.isVoiceOver) Icons.Default.Mic else Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = audioClip.title,
                        color = Color.White,
                        fontSize = 10.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayheadIndicator(
    offsetDp: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .offset(x = offsetDp - 6.dp)
            .width(12.dp)
    ) {
        // Glowing Needle head
        Box(
            modifier = Modifier
                .size(12.dp)
                .background(TimelinePlayhead, CircleShape)
                .border(1.5.dp, Color.White, CircleShape)
                .align(Alignment.TopCenter)
        )

        // Needle line extending all the way down
        Box(
            modifier = Modifier
                .width(2.dp)
                .fillMaxHeight()
                .background(TimelinePlayhead)
                .align(Alignment.TopCenter)
        )
    }
}
