package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AspectRatio
import com.example.ui.theme.VynoxBorder
import com.example.ui.theme.VynoxElectricBlue

@Composable
fun AspectRatioBadge(
    ratio: AspectRatio,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(Color(0xFF1B1A28), RoundedCornerShape(6.dp))
            .border(1.dp, VynoxBorder, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = when (ratio) {
                AspectRatio.RATIO_9_16 -> "9:16"
                AspectRatio.RATIO_16_9 -> "16:9"
                AspectRatio.RATIO_1_1 -> "1:1"
                AspectRatio.RATIO_4_5 -> "4:5"
            },
            color = VynoxElectricBlue,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
