package com.example.ui.editor

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.VynoxBlack
import com.example.ui.theme.VynoxCardSurface
import com.example.ui.theme.VynoxElectricBlue
import com.example.ui.theme.VynoxPurple
import com.example.ui.theme.VynoxTextMuted
import com.example.ui.theme.VynoxTextPrimary
import com.example.ui.theme.VynoxTextSecondary
import com.example.viewmodel.EditorViewModel
import kotlinx.coroutines.launch

@Composable
fun EditorScreen(
    projectId: String,
    viewModel: EditorViewModel,
    onNavigateBack: () -> Unit,
    onNavigateExport: (projectId: String) -> Unit
) {
    val project by viewModel.project.collectAsState()
    val playheadMs by viewModel.playheadPositionMs.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val selectedClipIndex by viewModel.selectedClipIndex.collectAsState()
    val timelineZoom by viewModel.timelineZoom.collectAsState()
    val canUndo by viewModel.canUndo.collectAsState()
    val canRedo by viewModel.canRedo.collectAsState()
    val saveMessage by viewModel.saveMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var showRenameDialog by remember { mutableStateOf(false) }
    var renameInput by remember { mutableStateOf("") }

    LaunchedEffect(projectId) {
        viewModel.loadProject(projectId)
    }

    LaunchedEffect(saveMessage) {
        saveMessage?.let {
            snackbarHostState.showSnackbar(it)
        }
    }

    BackHandler {
        viewModel.pause()
        onNavigateBack()
    }

    if (project == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(VynoxBlack),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = VynoxElectricBlue)
        }
        return
    }

    Scaffold(
        containerColor = VynoxBlack,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            // Editor Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .background(Color(0xFF141320))
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Back & Project Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    IconButton(
                        onClick = {
                            viewModel.pause()
                            onNavigateBack()
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to home",
                            tint = VynoxTextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = project?.name ?: "Vynox Editor",
                        color = VynoxTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .clickable {
                                renameInput = project?.name ?: ""
                                showRenameDialog = true
                            }
                            .testTag("editor_project_title")
                    )
                }

                // Center/Right Actions: Undo, Redo, Save, Export
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Undo
                    IconButton(
                        onClick = { viewModel.undo() },
                        enabled = canUndo,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "Undo",
                            tint = if (canUndo) VynoxTextPrimary else VynoxTextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Redo
                    IconButton(
                        onClick = { viewModel.redo() },
                        enabled = canRedo,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Redo,
                            contentDescription = "Redo",
                            tint = if (canRedo) VynoxTextPrimary else VynoxTextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Save
                    IconButton(
                        onClick = { viewModel.saveProjectManually() },
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = "Save project",
                            tint = VynoxElectricBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Watermark-Free Export Button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.horizontalGradient(listOf(VynoxPurple, VynoxElectricBlue))
                            )
                            .clickable {
                                viewModel.pause()
                                onNavigateExport(projectId)
                            }
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                            .testTag("top_export_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FileDownload,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Export",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Preview Canvas Area
            VideoPreviewArea(
                project = project!!,
                playheadMs = playheadMs,
                isPlaying = isPlaying,
                onPlayPause = { viewModel.togglePlayPause() },
                onSeek = { viewModel.seekTo(it) },
                onStep = { viewModel.stepFrame(it) },
                modifier = Modifier.fillMaxWidth()
            )

            // Timeline Area (Middle)
            TimelineView(
                project = project!!,
                playheadMs = playheadMs,
                selectedClipIndex = selectedClipIndex,
                timelineZoom = timelineZoom,
                onSeek = { viewModel.seekTo(it) },
                onSelectClip = { viewModel.selectClip(it) },
                onTrimClip = { index, start, end -> viewModel.trimClip(index, start, end) },
                onSplitClip = { viewModel.splitClipAtPlayhead() },
                onDuplicateClip = { viewModel.duplicateClip(it) },
                onDeleteClip = { viewModel.deleteClip(it) },
                onZoomChange = { viewModel.setTimelineZoom(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            )

            // Bottom Toolbars & Sub-Panels
            EditorToolbars(
                viewModel = viewModel,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    // Rename Dialog
    if (showRenameDialog) {
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Rename Project", color = VynoxTextPrimary) },
            text = {
                OutlinedTextField(
                    value = renameInput,
                    onValueChange = { renameInput = it },
                    label = { Text("Project Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VynoxPurple,
                        focusedTextColor = VynoxTextPrimary,
                        unfocusedTextColor = VynoxTextPrimary
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.renameProject(renameInput)
                        showRenameDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VynoxPurple)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = false }) {
                    Text("Cancel", color = VynoxTextSecondary)
                }
            },
            containerColor = VynoxCardSurface
        )
    }
}
