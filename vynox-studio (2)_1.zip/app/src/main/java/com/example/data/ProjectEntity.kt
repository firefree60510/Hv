package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val createdAt: Long,
    val lastModifiedAt: Long,
    val aspectRatioName: String,
    val durationMs: Long,
    val thumbnailUri: String?,
    val projectJson: String
)
